#include "RLEList.h"

struct RLEList_t {
    //TODO: implement
};

//implement the functions here
